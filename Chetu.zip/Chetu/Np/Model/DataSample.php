<?php 
	namespace Chetu\Np\Model;
	class DataSample extends \Magento\Framework\Model\AbstractModel{
		const EMPLOYEE_ID             = 'employee_id';
		const EMPLOYEE_NAME           = 'employee_name';
    	const EMPLOYEE_AGE            = 'employee_age';
    	const EMPLOYEE_DESCRIPTION    = 'employee_description';
    	const EMPLOYEE_COLOR          = 'employee_color';
    	const EMPLOYEE_ADDRESS        = 'employee_address';
    	const EMPLOYEE_GENDER         = 'employee_gender';
		public function _construct(){
			$this->_init("Chetu\Np\Model\ResourceModel\DataSample");
		}

    	public function getEmployeeId()
    	{
    	    return $this->getData(self::EMPLOYEE_ID);
    	}
		public function getEmployeeName()
    	{
    	    return $this->getData(self::EMPLOYEE_NAME);
    	}
		public function getEmployeeAge()
    	{
    	    return $this->getData(self::EMPLOYEE_AGE);
    	}
		public function getEmployeeDescription()
    	{
    	    return $this->getData(self::EMPLOYEE_DESCRIPTION);
    	}
		public function getEmployeeColor()
    	{
    	    return $this->getData(self::EMPLOYEE_COLOR);
    	}
		public function getEmployeeAddress()
    	{
    	    return $this->getData(self::EMPLOYEE_ADDRESS);
    	}
		public function getEmployeeGender()
    	{
    	    return $this->getData(self::EMPLOYEE_GENDER);
    	}
	}
?>