<?php 
    namespace Chetu\Np\Model\ResourceModel\DataSample;
    class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{
    	public function _construct(){
    		$this->_init("Chetu\Np\Model\DataSample","Chetu\Np\Model\ResourceModel\DataSample");
    	}
    }
?>