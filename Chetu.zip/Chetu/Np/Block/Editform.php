<?php
 
namespace Chetu\Np\Block;
 
use Magento\Backend\Block\Template\Context;
use Magento\Framework\View\Element\Template;
use Magento\Framework\Registry;
use Chetu\Np\Model\DataSampleFactory;
 
class Editform extends Template
{
    private $datasampleFactory;
 
    public function __construct(DataSampleFactory $datasampleFactory, Registry $coreRegistry, Context $context, array $data = [])
    {
        parent::__construct($context, $data);
        $this->_coreRegistry = $coreRegistry;
        $this->datasampleFactory = $datasampleFactory;
    }

    public function getFormAction()
    {
        return $this->getUrl('extension/index/result', ['_secure' => true]);
    }
 
    public function getAllData()
    {
        $employee_id = $this->getRequest()->getParam("employee_id");
        $model = $this->datasampleFactory->create();
        return $model->load($employee_id);
    }
    public function getEditData()
    {
         $id = $this->_coreRegistry->registry('employee_Id');
         $postData = $this->datasampleFactory->create();
         $result = $postData->load($id);
         $result = $result->getData();
         return $result;
    }
}