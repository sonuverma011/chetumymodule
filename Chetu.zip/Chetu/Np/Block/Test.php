<?php
namespace Chetu\Np\Block;
 
use Magento\Backend\Block\Template\Context;
use Magento\Framework\View\Element\Template;
use Chetu\Np\Model\DataSampleFactory;

class Test extends \Magento\Framework\View\Element\Template
{
    private $datasampleFactory;
 
    public function __construct(DataSampleFactory $datasampleFactory, Context $context, array $data = [])
    {
        parent::__construct($context, $data);
        $this->datasampleFactory = $datasampleFactory;
    }
 
    public function getFormAction()
    {
        return $this->getUrl('uiform/index/result', ['_secure' => true]);
    }
 
    public function getAllData()
    {
        $employee_id = $this->getRequest()->getParams();
        $model = $this->datasampleFactory->create();
        return $model->load($employee_id);
    }
}
