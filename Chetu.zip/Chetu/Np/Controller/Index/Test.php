<?php
namespace Chetu\Np\Controller\Index;

class Test extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Store\Model\StoreManagerInterface $storeManager)// \Magento\Framework\App\ResourceConnection $resource,
	{
		$this->_pageFactory = $pageFactory;
		$this->_storeManager = $storeManager;
		return parent::__construct($context);
	}
	// $this->_resource = $resource; //for creating object in constructor

	public function execute()
	{
		$resultpage = $this->_pageFactory->create();
		return $resultpage;
	}
}	