<?php
 
namespace Chetu\Np\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Result\PageFactory;
use Chetu\Np\Model\DataSampleFactory;
 
class Edit extends Action
{
    protected $resultPageFactory;
 
    private $datasampleFactory;
 
    private $url;

    protected $_request;
    protected $_coreRegistry;
 
    public function __construct(
            UrlInterface $url, DataSampleFactory $datasampleFactory, Context $context, 
            \Magento\Framework\App\Request\Http $request,
            \Magento\Framework\Registry $coreRegistry,
            PageFactory $resultPageFactory
            )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->datasampleFactory = $datasampleFactory;
        $this->url = $url;
    }
 
    public function execute()
    {
        if ($this->isCorrectData()) {
            return $this->resultPageFactory->create();
        } else {
            $this->messageManager->addErrorMessage(__("Record Not Found"));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->url->getUrl('uiform/index/dispdata'));
            return $resultRedirect;
        }
    }
 
    public function isCorrectData()
    {
        if ($employee_id = $this->getRequest()->getParam("employee_id")) {
            $model = $this->datasampleFactory->create();
            $model->load($employee_id);
            if ($model->getEmployeeId()) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}