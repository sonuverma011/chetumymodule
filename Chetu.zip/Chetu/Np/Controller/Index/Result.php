<?php
 
namespace Chetu\Np\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Result\PageFactory;
use Chetu\Np\Model\DataSampleFactory;
 
class Result extends Action
{
    protected $resultPageFactory;
    protected $datasampleFactory;
    private $url;
 
    public function __construct(
        UrlInterface $url,
        Context $context,
        PageFactory $resultPageFactory,
        DataSampleFactory $datasampleFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->datasampleFactory = $datasampleFactory;
        $this->url = $url;
        parent::__construct($context);
    }
 
    public function execute()
    {
        
        $model = $this->datasampleFactory->create();
        if(!empty($emp_name && $emp_age && $emp_age && $emp_description && $emp_color)){
        $emp_name= $this->getRequest()->getParam('employee_name');
        }
        
        $emp_age = $this->getRequest()->getParam('employee_age');
        $emp_description= $this->getRequest()->getParam('employee_description');
        $emp_color= $this->getRequest()->getParam('employee_color');
        $emp_address= $this->getRequest()->getParam('employee_address');
        $emp_gender= $this->getRequest()->getParam('employee_gender');

		$model->addData([
				"employee_name" => $emp_name,
				"employee_age" => $emp_age,
				"employee_description" => $emp_description,
				"employee_color" => $emp_color,
				"employee_address" => $emp_address,
				"employee_gender" => $emp_gender,
				"sort_order" => 1
				]);
    $saveData = $model->save();
    if($saveData){
        $this->messageManager->addSuccess( __('Insert Record Successfully !') );
    }
    $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
    $resultRedirect->setUrl($this->url->getUrl('uiform/index/dispdata'));
    return $resultRedirect;
    }
}